# Concepts

## Client Script vs UI Policy
| | UI Policy | Client Script |
|---|---|---|
| Setup | No-code conditions + actions | JavaScript |
| Actions | Mandatory, visible, read-only | Anything g_form/g_user allows |
| Reverses automatically | Yes ("Reverse if false") | No, you code both branches |
| Runs | onLoad and on field change | onLoad, onChange, onSubmit, onCellEdit |
| Order | Runs after Client Scripts | Runs first |
| Best for | Simple field state rules | Validation, messages, lookups |

Rule of thumb: use a UI Policy when you can; use a Client Script when you need logic.

## Client script types
- onLoad: when the form opens
- onChange: when a chosen field changes (guard with `isLoading`)
- onSubmit: when saving; return `false` to cancel
- onCellEdit: list inline editing

## g_form cheat sheet
- `g_form.getValue('f')`, `g_form.setValue('f', v)`
- `g_form.setMandatory('f', bool)`, `g_form.setReadOnly('f', bool)`, `g_form.setDisplay('f', bool)`, `g_form.setVisible('f', bool)`
- `g_form.showFieldMsg('f', msg, 'info|error')`, `g_form.hideFieldMsg('f', true)`
- `g_form.addInfoMessage(msg)`, `g_form.addErrorMessage(msg)`, `g_form.clearMessages()`
- `g_form.getReference('ref_field', callback)` (always use the callback)
- `g_user.hasRole('itil')`

## Best practices
- Avoid synchronous GlideRecord on the client; use getReference with a callback or GlideAjax.
- Always check `isLoading` in onChange when you only want user-driven changes.
- Don't use DOM manipulation; use the supported g_form API.
