# Implementation Steps
1. Log in to your PDI as admin. Create an Update Set named "Client Scripts and UI Policy" and make it current.
2. **Client Scripts:** System Definition > Client Scripts > New.
   For each file in `client_scripts/`, set Name, Table = Incident, Type, Field name (onChange only), Active = true, and paste the script.
3. **UI Policies:** System UI > UI Policies > New (or right-click the form header > Configure > UI Policies).
   For each file in `ui_policies/`, fill the header and conditions, save, then add the rows in the **UI Policy Actions** related list.
   For policy 04, tick "Run scripts" and paste both scripts.
4. Open Incident > New and run through `docs/test_cases.md`.
5. Export the update set (Retrieved/Local Update Sets > Export to XML) as your deliverable.
