# Test Cases
| # | Steps | Expected |
|---|-------|----------|
| 1 | Open a new Incident | Welcome message shown, Contact type = Self-service |
| 2 | Set Category = Hardware | Info message under Category |
| 3 | Pick a VIP caller (e.g. Abel Tuter if flagged VIP) | VIP info message appears |
| 4 | Set Priority to 1 - Critical | Assignment group becomes mandatory, message shown |
| 5 | Short description "Help", Submit | Blocked with error under the field |
| 6 | Priority 1, no assignment group, Submit | Blocked with error message and field flash |
| 7 | Set State = Resolved | Close code and Close notes mandatory |
| 8 | Set State = On Hold | Hold reason appears and is mandatory; other states hide it |
| 9 | Reopen a saved incident | Caller is read-only |
| 10 | Impersonate a user without itil role | Business service hidden |
