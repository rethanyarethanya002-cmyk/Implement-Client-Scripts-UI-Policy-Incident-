/*
 * Name:   Incident - Category Hardware Warning
 * Table:  Incident [incident]
 * Type:   onChange
 * Field:  Category
 */
function onChange(control, oldValue, newValue, isLoading, isTemplate) {
    if (isLoading || newValue === '') {
        return;
    }
    g_form.clearMessages();
    if (newValue === 'hardware') {
        g_form.showFieldMsg('category', 'Hardware incidents: include asset tag in the description.', 'info');
    }
}
