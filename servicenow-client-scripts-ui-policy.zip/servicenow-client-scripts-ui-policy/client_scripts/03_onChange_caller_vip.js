/*
 * Name:   Incident - VIP Caller Alert
 * Table:  Incident [incident]
 * Type:   onChange
 * Field:  Caller
 */
function onChange(control, oldValue, newValue, isLoading, isTemplate) {
    if (isLoading || newValue === '') {
        return;
    }
    // Async reference lookup (avoids blocking the UI)
    g_form.getReference('caller_id', function (caller) {
        if (caller.vip == 'true') {
            g_form.addInfoMessage('VIP caller: ' + caller.name + '. Handle with priority.');
            g_form.showFieldMsg('caller_id', 'VIP user', 'info');
        } else {
            g_form.hideFieldMsg('caller_id', true);
        }
    });
}
