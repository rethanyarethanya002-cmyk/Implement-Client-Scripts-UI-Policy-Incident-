/*
 * Name:   Incident - Welcome on Load
 * Table:  Incident [incident]
 * Type:   onLoad
 * UI Type: All
 */
function onLoad() {
    // New record only
    if (g_form.isNewRecord()) {
        g_form.addInfoMessage('Welcome! Please fill in the Caller and Short description first.');
        g_form.setValue('contact_type', 'self-service');
        g_form.setMandatory('short_description', true);
        g_form.setFieldPlaceholder && g_form.setFieldPlaceholder('short_description', 'Briefly describe the issue');
    }
}
