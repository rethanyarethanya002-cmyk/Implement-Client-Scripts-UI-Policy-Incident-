/*
 * Name:   Incident - Priority 1 Guidance
 * Table:  Incident [incident]
 * Type:   onChange
 * Field:  Priority
 */
function onChange(control, oldValue, newValue, isLoading, isTemplate) {
    if (isLoading || newValue === '') {
        return;
    }
    if (newValue == '1') {
        g_form.setMandatory('assignment_group', true);
        g_form.showFieldMsg('priority', 'Critical: an assignment group is required.', 'error');
    } else {
        g_form.setMandatory('assignment_group', false);
        g_form.hideFieldMsg('priority', true);
    }
}
