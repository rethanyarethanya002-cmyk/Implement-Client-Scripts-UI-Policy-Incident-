/*
 * Name:   Incident - P1 Requires Assignment Group
 * Table:  Incident [incident]
 * Type:   onSubmit
 */
function onSubmit() {
    if (g_form.getValue('priority') == '1' && g_form.getValue('assignment_group') == '') {
        g_form.addErrorMessage('Priority 1 incidents must have an Assignment group.');
        g_form.flash('assignment_group', '#FFCCCC', 0);
        return false;
    }
    return true;
}
