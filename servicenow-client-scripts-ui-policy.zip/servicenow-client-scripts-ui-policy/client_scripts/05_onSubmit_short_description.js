/*
 * Name:   Incident - Validate Short Description
 * Table:  Incident [incident]
 * Type:   onSubmit
 */
function onSubmit() {
    var desc = g_form.getValue('short_description').trim();
    if (desc.length < 10) {
        g_form.showFieldMsg('short_description', 'Enter at least 10 characters.', 'error');
        return false; // stops the submit
    }
    return true;
}
