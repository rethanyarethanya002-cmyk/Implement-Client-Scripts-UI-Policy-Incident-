# UI Policy: Hold reason on On Hold
- Table: Incident
- Short description: Show Hold reason when On Hold
- Global: true, On load: true, Reverse if false: true
- Conditions: `State` is `On Hold`

| Field | Mandatory | Visible | Read only |
|-------|-----------|---------|-----------|
| Hold reason | True | True | Leave alone |

Reverse if false hides and un-requires the field again for other states.
