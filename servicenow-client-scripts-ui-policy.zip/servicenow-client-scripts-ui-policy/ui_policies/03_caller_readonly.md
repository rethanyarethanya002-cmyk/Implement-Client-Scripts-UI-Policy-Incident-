# UI Policy: Caller read-only after save
- Table: Incident
- Short description: Lock Caller on existing records
- Global: true, On load: true, Reverse if false: true
- Conditions: `Number` is not empty   (a saved record always has a number)

| Field | Mandatory | Visible | Read only |
|-------|-----------|---------|-----------|
| Caller | Leave alone | Leave alone | True |
