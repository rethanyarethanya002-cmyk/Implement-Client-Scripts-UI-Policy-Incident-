# UI Policy: Close notes mandatory on Resolved/Closed
- Table: Incident
- Short description: Close notes mandatory when resolved
- Global: true, On load: true, Reverse if false: true
- Conditions: `State` is `Resolved` **OR** `State` is `Closed`

| Field | Mandatory | Visible | Read only |
|-------|-----------|---------|-----------|
| Close code  | True | Leave alone | Leave alone |
| Close notes | True | Leave alone | Leave alone |
