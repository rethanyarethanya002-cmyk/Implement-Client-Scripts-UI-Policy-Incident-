# UI Policy: Hide Business service for non-ITIL users (scripted)
- Table: Incident
- Short description: Hide Business service from non-ITIL
- Global: false, On load: true, Reverse if false: false
- Conditions: none (always runs)
- Tick "Run scripts" and set UI Type: Desktop

## Execute if true
```javascript
function onCondition() {
    if (!g_user.hasRole('itil')) {
        g_form.setDisplay('business_service', false);
    }
}
```

## Execute if false
```javascript
function onCondition() {
    g_form.setDisplay('business_service', true);
}
```
