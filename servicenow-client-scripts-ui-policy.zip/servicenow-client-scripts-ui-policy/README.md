# ServiceNow Project: Client Scripts & UI Policies

Hands-on project that implements form behavior on the **Incident** table using
Client Scripts and UI Policies. Use a Personal Developer Instance (developer.servicenow.com).

## Structure
- `client_scripts/` – 6 scripts (onLoad, onChange x3, onSubmit x2), ready to paste
- `ui_policies/`    – 4 UI Policy definitions (conditions, actions, optional scripts)
- `docs/concepts.md`      – Client Script vs UI Policy, g_form API cheat sheet
- `docs/test_cases.md`    – Step-by-step verification checklist
- `docs/implementation_steps.md` – Where to click in ServiceNow

## Requirements covered
| # | Requirement | Implemented with |
|---|-------------|------------------|
| 1 | Welcome/info message and focus on form load | Client Script (onLoad) |
| 2 | Warn when Category = Hardware | Client Script (onChange) |
| 3 | Show VIP alert when Caller is VIP | Client Script (onChange, g_form.getReference) |
| 4 | Auto-set Urgency/Impact hint when Priority = 1 | Client Script (onChange) |
| 5 | Short description must be 10+ characters | Client Script (onSubmit) |
| 6 | P1 incidents need an Assignment group | Client Script (onSubmit) |
| 7 | Close notes mandatory when Resolved/Closed | UI Policy |
| 8 | Show Hold reason only when On Hold (mandatory) | UI Policy |
| 9 | Caller read-only after record is saved | UI Policy |
| 10 | Hide Business service for non-ITIL users | UI Policy (script) |

Start with `docs/implementation_steps.md`.
